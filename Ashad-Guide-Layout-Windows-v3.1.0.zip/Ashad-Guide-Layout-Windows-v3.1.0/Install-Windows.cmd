@echo off
setlocal
if not exist "%~dp0Install-Windows.ps1" goto missing
if not exist "%~dp0Compatibility.ps1" goto missing
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Windows.ps1" %*
set "AshadExitCode=%ERRORLEVEL%"
if not "%AshadExitCode%"=="0" echo Operation failed. Read the error above before retrying.
pause
exit /b %AshadExitCode%
:missing
echo Missing package files. Extract the complete ZIP before running this file.
pause
exit /b 1
