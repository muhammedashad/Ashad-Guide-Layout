$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Compatibility.ps1')
$target = Get-AshadPanelPath
$installReceipt = Join-Path $target 'install-receipt.json'
if (!(Test-Path -LiteralPath $installReceipt)) { throw 'No installer receipt found. No files removed. Manual installations must be removed manually.' }
$saved = Get-Content -LiteralPath $installReceipt -Raw | ConvertFrom-Json
if ($saved.ExtensionId -ne $AshadExtensionId) { throw 'Invalid install receipt. Nothing removed.' }
if (Get-Process -Name Illustrator -ErrorAction SilentlyContinue) { throw 'Save and close Illustrator first.' }
if ((Read-Host 'Remove this per-user Ashad Guide Layout panel? Type YES') -cne 'YES') { return }
if ((Read-Host 'Type RESTORE to restore the saved CEP settings, or press Enter to keep them for other panels') -ceq 'RESTORE') {
    Restore-AshadSettings (Get-AshadSettingsReceiptPath)
}
# Get-AshadPanelPath verifies the resolved direct child before this recursive removal.
Remove-Item -LiteralPath $target -Recurse -Force
Write-Host 'Removed the per-user panel. Manual application-folder copies and your documents were kept.'
