param([string]$IllustratorPath, [string[]]$IllustratorVersion = @(), [switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Compatibility.ps1')
$source = Join-Path $PSScriptRoot $AshadExtensionId
Test-AshadPanel $source
$detected = @(Find-AshadIllustrators $IllustratorPath)
$ceps = @(Resolve-AshadCepMajors $IllustratorVersion $detected)
$target = Get-AshadPanelPath
Write-Host 'Ashad Guide Layout 3.1.0 - Illustrator 2019-2026 compatibility package'
foreach ($appInfo in $detected) { Write-Host "Detected Illustrator $($appInfo.Version) / CEP $($appInfo.Cep)" }
Write-Host "Install location: $target"
Write-Host "Enables unsigned panels for CEP: $($ceps -join ', '). This also permits other unsigned panels for your Windows user."
if ($CheckOnly) { Write-Host 'CHECK PASSED. No installation or settings changes made.'; return }
if (Get-Process -Name Illustrator -ErrorAction SilentlyContinue) { throw 'Save and close all Illustrator versions, then run this installer again.' }
if ((Read-Host 'Install and enable these settings? Type YES') -cne 'YES') { Write-Host 'Cancelled.'; return }
$legacy = Join-Path $target 'install-receipt.json'
if (Test-Path -LiteralPath $target) {
    [xml]$previous = Get-Content -LiteralPath (Join-Path $target 'CSXS\manifest.xml') -Raw
    if ($previous.ExtensionManifest.ExtensionBundleId -ne $AshadExtensionId) { throw 'Existing folder belongs to another extension.' }
    $backupRoot = Join-Path $env:LOCALAPPDATA 'Ashad\Guide Layout\Extension backups'
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $backup = Join-Path $backupRoot ([guid]::NewGuid().ToString('N'))
    Copy-Item -LiteralPath $target -Destination $backup -Recurse
    Write-Host "Previous panel backed up: $backup"
}
# Validate the existing receipt before overwriting any panel files.
$receipt = Get-AshadSettingsReceiptPath
$null = @(Read-AshadSettingsReceipt $receipt $legacy)
New-Item -ItemType Directory -Path $target -Force | Out-Null
foreach ($item in Get-ChildItem -LiteralPath $source) { Copy-Item -LiteralPath $item.FullName -Destination $target -Recurse -Force }
Test-AshadPanel $target
Enable-AshadSettings $ceps $receipt $legacy
@{ExtensionId=$AshadExtensionId;SchemaVersion=2;Version='3.1.0'} | ConvertTo-Json | Set-Content -LiteralPath $legacy -Encoding UTF8
Write-Host 'Installed. Restart Illustrator, then open Window > Extensions > Ashad Guide Layout.' -ForegroundColor Green
Write-Host 'If you later install another Illustrator version, run this installer or repair again to detect its CEP runtime.'
