param([string]$IllustratorPath, [string[]]$IllustratorVersion = @(), [switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Compatibility.ps1')
$detected = @(Find-AshadIllustrators $IllustratorPath)
$ceps = @(Resolve-AshadCepMajors $IllustratorVersion $detected)
$target = Get-AshadPanelPath
$candidates = @($target)
foreach ($appInfo in $detected) {
    # Executable lives in Support Files/Contents/Windows (or Windows64).
    $support = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $appInfo.Exe))
    $candidates += Join-Path $support "Required\CEP\extensions\$AshadExtensionId"
}
foreach ($base in @($env:ProgramFiles,${env:ProgramFiles(x86)})) {
    if ($base) { $candidates += Join-Path $base "Common Files\Adobe\CEP\extensions\$AshadExtensionId" }
}
$found = @($candidates | Select-Object -Unique | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'CSXS\manifest.xml') })
if (!$found.Count) { throw 'Panel not found. Run Install-Windows.cmd from the complete 3.1.0 package first.' }
# Prefer the current per-user panel. Old application-folder copies do not block its repair.
if (Test-Path -LiteralPath (Join-Path $target 'CSXS\manifest.xml')) { Test-AshadPanel $target; Write-Host "Checked: $target" }
else { foreach ($folder in $found) { Test-AshadPanel $folder; Write-Host "Checked: $folder" } }
Write-Host "Matching CEP runtimes: $($ceps -join ', ')"
if ($CheckOnly) { Write-Host 'CHECK PASSED. No settings changed.'; return }
if (Get-Process -Name Illustrator -ErrorAction SilentlyContinue) { throw 'Save and close all Illustrator versions, then run repair again.' }
Write-Host 'This enables unsigned panels for the listed CEP runtimes, including other unsigned panels for your user.'
if ((Read-Host 'Enable these settings? Type YES') -cne 'YES') { Write-Host 'Cancelled.'; return }
Enable-AshadSettings $ceps (Get-AshadSettingsReceiptPath) (Join-Path $target 'install-receipt.json')
Write-Host 'REPAIR SETTING VERIFIED.' -ForegroundColor Green
Write-Host 'Restart Illustrator. Open Window > Extensions > Ashad Guide Layout.'
