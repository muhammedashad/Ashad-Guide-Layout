# Copyright (c) 2026 Ashad. All rights reserved.
# Shared by installer, repair and uninstaller. Loading this file changes nothing.
$AshadExtensionId = 'com.ashad.guidelayout'

function Get-AshadCepMajor([string]$IllustratorVersion) {
    if ($IllustratorVersion -notmatch '^\s*(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:\.\d+)?\s*$') { throw "Invalid Illustrator version: $IllustratorVersion. Use a number such as 24.0 or 29.5.1." }
    $major = [int]$Matches[1]; $minor = [int]$Matches[2]; $patch = 0
    if ($Matches[3]) { $patch = [int]$Matches[3] }
    if ($major -lt 23 -or $major -gt 30) { throw "Illustrator $IllustratorVersion is outside this package's target range (23.x-30.x / 2019-2026)." }
    if ($major -le 24) { return 9 }
    if ($major -eq 25 -and $minor -lt 3) { return 10 }
    if ($major -lt 29 -or ($major -eq 29 -and ($minor -lt 5 -or ($minor -eq 5 -and $patch -lt 1)))) { return 11 }
    return 12
}

function Find-AshadIllustrators([string]$IllustratorPath) {
    $roots = @(); $executables = @()
    foreach ($base in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($base -and (Test-Path -LiteralPath (Join-Path $base 'Adobe'))) {
            $roots += @(Get-ChildItem -LiteralPath (Join-Path $base 'Adobe') -Directory -Filter '*Illustrator*' -ErrorAction SilentlyContinue | ForEach-Object FullName)
        }
    }
    foreach ($reg in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')) {
        if (Test-Path -LiteralPath $reg) {
            $roots += @(Get-ChildItem -LiteralPath $reg -ErrorAction SilentlyContinue | Get-ItemProperty -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like '*Adobe Illustrator*' -and $_.InstallLocation } | ForEach-Object InstallLocation)
        }
    }
    if ($IllustratorPath) {
        if (!(Test-Path -LiteralPath $IllustratorPath)) { throw 'The supplied Illustrator path does not exist.' }
        if (Test-Path -LiteralPath $IllustratorPath -PathType Leaf) { $executables += $IllustratorPath }
        else { $roots += $IllustratorPath }
    }
    foreach ($root in @($roots | Select-Object -Unique)) {
        foreach ($relative in @('Support Files\Contents\Windows\Illustrator.exe', 'Support Files\Contents\Windows64\Illustrator.exe', 'Illustrator.exe')) {
            $candidate = Join-Path $root $relative
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { $executables += $candidate }
        }
    }
    foreach ($exe in @($executables | Select-Object -Unique)) {
        $file = Get-Item -LiteralPath $exe
        if ($file.Name -ine 'Illustrator.exe') { continue }
        $version = $file.VersionInfo.ProductVersion
        if (!$version) { $version = $file.VersionInfo.FileVersion }
        try {
            $cep = Get-AshadCepMajor $version
            [pscustomobject]@{ Version = $version; Cep = $cep; Exe = $file.FullName }
        } catch { Write-Warning $_.Exception.Message }
    }
}

function Resolve-AshadCepMajors([string[]]$IllustratorVersion, [object[]]$Detected) {
    if ($IllustratorVersion.Count) { return @($IllustratorVersion | ForEach-Object { Get-AshadCepMajor $_ } | Sort-Object -Unique) }
    if ($Detected.Count) { return @($Detected | ForEach-Object Cep | Sort-Object -Unique) }
    throw 'No supported Illustrator installation detected. Run this script with -IllustratorPath pointing to Illustrator.exe, or -IllustratorVersion 24.0 (2020), 29.0 (2025), etc. See COMPATIBILITY.md.'
}

function Get-AshadPanelPath {
    $root = [IO.Path]::GetFullPath((Join-Path $env:APPDATA 'Adobe\CEP\extensions'))
    $target = [IO.Path]::GetFullPath((Join-Path $root $AshadExtensionId))
    if ([IO.Path]::GetDirectoryName($target) -ne $root -or [IO.Path]::GetFileName($target) -ne $AshadExtensionId) { throw 'Unexpected extension path.' }
    return $target
}

function Test-AshadPanel([string]$PanelPath) {
    foreach ($file in @('CSXS\manifest.xml','index.html','style.css','panel.js','host.jsx','core.js','wire.js','social.js')) {
        if (!(Test-Path -LiteralPath (Join-Path $PanelPath $file) -PathType Leaf)) { throw "Missing panel file: $PanelPath\$file. Extract and install the complete ZIP." }
    }
    [xml]$manifest = Get-Content -LiteralPath (Join-Path $PanelPath 'CSXS\manifest.xml') -Raw
    if ($manifest.ExtensionManifest.ExtensionBundleId -ne $AshadExtensionId) { throw 'Unexpected extension ID.' }
    if ([version]$manifest.ExtensionManifest.ExtensionBundleVersion -lt [version]'3.1.0') { throw 'This is an older, restricted panel. Install the complete version 3.1.0 package first; repair alone cannot widen its compatibility.' }
}

function Get-AshadSetting([int]$Cep) {
    $keyPath = "HKCU:\Software\Adobe\CSXS.$Cep"
    if (Test-Path -LiteralPath $keyPath) {
        $key = Get-Item -LiteralPath $keyPath
        try {
            if ($key.GetValueNames() -contains 'PlayerDebugMode') {
                return [pscustomobject]@{ Cep=$Cep; HadValue=$true; OldValue=$key.GetValue('PlayerDebugMode'); OldKind=$key.GetValueKind('PlayerDebugMode').ToString() }
            }
        } finally { $key.Close() }
    }
    return [pscustomobject]@{ Cep=$Cep; HadValue=$false; OldValue=$null; OldKind='String' }
}

function Write-AshadSetting([int]$Cep) {
    if ($Cep -notin @(9,10,11,12)) { throw 'Invalid CEP version.' }
    $keyPath = "HKCU:\Software\Adobe\CSXS.$Cep"
    New-Item -Path $keyPath -Force | Out-Null
    New-ItemProperty -LiteralPath $keyPath -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
    $value = Get-AshadSetting $Cep
    if (!$value.HadValue -or $value.OldKind -ne 'String' -or $value.OldValue -cne '1') { throw "CEP $Cep setting verification failed." }
}

function Read-AshadSettingsReceipt([string]$ReceiptPath, [string]$LegacyReceipt) {
    $states = @()
    if (Test-Path -LiteralPath $ReceiptPath) {
        $saved = Get-Content -LiteralPath $ReceiptPath -Raw | ConvertFrom-Json
        if ($saved.ExtensionId -ne $AshadExtensionId -or $saved.SchemaVersion -ne 2) { throw 'Unrecognized settings receipt; no settings changed.' }
        $states = @($saved.Settings)
    } elseif ($LegacyReceipt -and (Test-Path -LiteralPath $LegacyReceipt)) {
        $old = Get-Content -LiteralPath $LegacyReceipt -Raw | ConvertFrom-Json
        if ($old.ExtensionId -ne $AshadExtensionId) { throw 'Unrecognized previous install receipt.' }
        if ($null -ne $old.HadValue) { $states = @([pscustomobject]@{Cep=12;HadValue=$old.HadValue;OldValue=$old.OldValue;OldKind=$old.OldKind}) }
        elseif ($old.SchemaVersion -eq 2) { throw 'The settings receipt is missing. Restore it from your backup before changing settings.' }
    }
    foreach ($state in $states) {
        if ($state.Cep -notin @(9,10,11,12) -or $state.OldKind -notin @('String','ExpandString','DWord','QWord','MultiString','Binary') -or $state.HadValue -isnot [bool]) { throw 'Invalid saved setting; nothing changed.' }
    }
    return $states
}

function Enable-AshadSettings([int[]]$CepMajors, [string]$ReceiptPath, [string]$LegacyReceipt) {
    $states = @(Read-AshadSettingsReceipt $ReceiptPath $LegacyReceipt)
    foreach ($cep in $CepMajors) {
        if ($cep -notin @(9,10,11,12)) { throw 'Invalid CEP version.' }
        if (!@($states | Where-Object { $_.Cep -eq $cep }).Count) { $states += Get-AshadSetting $cep }
    }
    New-Item -ItemType Directory -Path (Split-Path -Parent $ReceiptPath) -Force | Out-Null
    # Preserve every original value before changing any registry key, including across upgrades.
    $json = [ordered]@{ExtensionId=$AshadExtensionId;SchemaVersion=2;Settings=@($states)} | ConvertTo-Json -Depth 8
    $temp = "$ReceiptPath.tmp"
    $json | Set-Content -LiteralPath $temp -Encoding UTF8
    Move-Item -LiteralPath $temp -Destination $ReceiptPath -Force
    foreach ($cep in $CepMajors) { Write-AshadSetting $cep }
}

function Restore-AshadSettings([string]$ReceiptPath) {
    if (!(Test-Path -LiteralPath $ReceiptPath)) { throw 'Settings receipt not found. No settings restored.' }
    $states = @(Read-AshadSettingsReceipt $ReceiptPath '')
    foreach ($state in $states) {
        $keyPath = "HKCU:\Software\Adobe\CSXS.$($state.Cep)"
        if ($state.HadValue) {
            New-Item -Path $keyPath -Force | Out-Null
            New-ItemProperty -LiteralPath $keyPath -Name PlayerDebugMode -Value $state.OldValue -PropertyType $state.OldKind -Force | Out-Null
        } elseif (Test-Path -LiteralPath $keyPath) { Remove-ItemProperty -LiteralPath $keyPath -Name PlayerDebugMode -ErrorAction SilentlyContinue }
    }
    # Archive the used receipt so reinstalling captures fresh preferences.
    Move-Item -LiteralPath $ReceiptPath -Destination ($ReceiptPath + '.restored-' + [guid]::NewGuid().ToString('N'))
}

function Get-AshadSettingsReceiptPath { return (Join-Path $env:LOCALAPPDATA 'Ashad\Guide Layout\settings-receipt.json') }
