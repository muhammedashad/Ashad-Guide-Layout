# Copyright (c) 2026 Ashad. All rights reserved.
[CmdletBinding()]
param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$registryPath = 'HKCU:\Software\Adobe\CSXS.12'
$extensionId = 'com.ashad.guidelayout'
$candidates = @(
    (Join-Path $env:APPDATA "Adobe\CEP\extensions\$extensionId"),
    (Join-Path $env:ProgramFiles "Adobe\Adobe Illustrator 2026\Support Files\Required\CEP\extensions\$extensionId"),
    (Join-Path $env:ProgramFiles "Common Files\Adobe\CEP\extensions\$extensionId")
)
if (${env:ProgramFiles(x86)}) {
    $candidates += Join-Path ${env:ProgramFiles(x86)} "Common Files\Adobe\CEP\extensions\$extensionId"
}
$found = @($candidates | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'CSXS\manifest.xml') })
if ($found.Count -eq 0) { throw 'Ashad Guide Layout was not found. Install the extension before running this repair.' }
foreach ($folder in $found) {
    [xml]$manifest = Get-Content -LiteralPath (Join-Path $folder 'CSXS\manifest.xml') -Raw
    if ($manifest.ExtensionManifest.ExtensionBundleId -ne $extensionId) { throw "Unexpected extension ID in $folder" }
    foreach ($file in @('index.html','style.css','panel.js','core.js','wire.js','host.jsx')) {
        if (!(Test-Path -LiteralPath (Join-Path $folder $file) -PathType Leaf)) { throw "Missing extension file: $folder\$file" }
    }
    Write-Host "Found complete panel: $folder"
}
if ($CheckOnly) { Write-Host 'Installation files checked. No registry access or changes requested.'; return }
$hadValue = $false
$oldValue = $null
$oldKind = $null
if (Test-Path -LiteralPath $registryPath) {
    $key = Get-Item -LiteralPath $registryPath
    try {
        $hadValue = $key.GetValueNames() -contains 'PlayerDebugMode'
        if ($hadValue) {
            $oldValue = $key.GetValue('PlayerDebugMode')
            $oldKind = $key.GetValueKind('PlayerDebugMode').ToString()
        }
    } finally { $key.Close() }
}
$alreadyEnabled = $hadValue -and $oldKind -eq 'String' -and $oldValue -ceq '1'
Write-Host "CEP 12 unsigned-extension setting enabled: $alreadyEnabled"

Write-Host 'This repair enables unsigned CEP 12 extensions for your Windows user.'
if (!$alreadyEnabled) {
    # Keep an exact record before making a change. Abort if the backup cannot be saved.
    $backupRoot = Join-Path $env:LOCALAPPDATA 'Ashad\Guide Layout\Repair backups'
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $backupPath = Join-Path $backupRoot ('CEP12-' + [guid]::NewGuid().ToString('N') + '.json')
    [ordered]@{
        Time = (Get-Date).ToString('o'); RegistryPath = $registryPath
        ValueName = 'PlayerDebugMode'; HadValue = $hadValue
        OldKind = $oldKind; OldValue = $oldValue
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $backupPath -Encoding UTF8
    Write-Host "Previous setting saved: $backupPath"
    New-Item -Path $registryPath -Force | Out-Null
    New-ItemProperty -LiteralPath $registryPath -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
}
$verify = Get-Item -LiteralPath $registryPath
try {
    if ($verify.GetValueKind('PlayerDebugMode').ToString() -ne 'String' -or $verify.GetValue('PlayerDebugMode') -cne '1') {
        throw 'The unsigned-extension setting could not be verified.'
    }
} finally { $verify.Close() }
Write-Host ''
Write-Host 'REPAIR SETTING VERIFIED.' -ForegroundColor Green
Write-Host 'Save your work. Close Illustrator normally, then reopen it.'
Write-Host 'Open Window > Extensions > Ashad Guide Layout.'
Write-Host 'The repair has not closed Illustrator or changed any extension files.'
