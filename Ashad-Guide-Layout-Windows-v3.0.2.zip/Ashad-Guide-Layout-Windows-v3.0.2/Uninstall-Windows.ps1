$ErrorActionPreference = 'Stop'
$extensionId = 'com.ashad.guidelayout'
$extensionRoot = [IO.Path]::GetFullPath((Join-Path $env:APPDATA 'Adobe\CEP\extensions'))
$targetPath = [IO.Path]::GetFullPath((Join-Path $extensionRoot $extensionId))
if ([IO.Path]::GetDirectoryName($targetPath) -ne $extensionRoot -or [IO.Path]::GetFileName($targetPath) -ne $extensionId) { throw 'Unexpected uninstall path.' }
$receiptPath = Join-Path $targetPath 'install-receipt.json'
if (!(Test-Path -LiteralPath $receiptPath)) { throw 'No installation receipt found. Nothing removed.' }
$receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
if ($receipt.ExtensionId -ne $extensionId) { throw 'Invalid installation receipt.' }
if (Get-Process Illustrator -ErrorAction SilentlyContinue) { throw 'Save and close Illustrator first.' }
if ((Read-Host 'Remove only Ashad Guide Layout? Type YES') -cne 'YES') { exit 0 }
$restore = (Read-Host 'Restore the previous CEP developer-mode setting? Type RESTORE, or Enter to keep it for other panels') -ceq 'RESTORE'
if ($restore) {
 $registryPath = 'HKCU:\Software\Adobe\CSXS.12'
 if ($receipt.HadValue) { New-ItemProperty -LiteralPath $registryPath -Name PlayerDebugMode -Value $receipt.OldValue -PropertyType $receipt.OldKind -Force | Out-Null }
 else { Remove-ItemProperty -LiteralPath $registryPath -Name PlayerDebugMode -ErrorAction SilentlyContinue }
}
Remove-Item -LiteralPath $targetPath -Recurse -Force
Write-Host 'Removed Ashad Guide Layout. KSDrafter and your documents were kept.'

