# Ashad Guide Layout — Illustrator Extension

Copyright © 2026 Ashad. All rights reserved.
Contact: +91 8590956012 | muhammedashad2005@gmail.com

This package contains a dockable CEP panel for Illustrator 2026 (30.x), designed to appear under **Window > Extensions > Ashad Guide Layout**. It does not require opening a JSX file to use it.

## Install or update on Windows

Version 3.0.2 uses six compact circular icon buttons: WhatsApp, Pinterest, Instagram, LinkedIn, GitHub and Behance. Each has a hover label and keyboard focus indicator. The Email button has been removed. Social links open in your default browser only when clicked.

1. Save your work and close Illustrator. Extract the entire ZIP. Do not run the installer from inside the ZIP viewer.
2. Double-click **Install-Windows.cmd**.
3. Read the message and type **YES** to install the panel and enable unsigned CEP 12 extensions for your Windows user.
4. Save your work, close Illustrator normally, then reopen it.
5. Open **Window > Extensions > Ashad Guide Layout**.
6. Drag the panel tab to dock it beside your other panels.

The extension installs to `%APPDATA%\Adobe\CEP\extensions\com.ashad.guidelayout`. It uses its own ID and keeps KSDrafter and other extensions unchanged. An existing per-user copy is backed up before updating. Version 3.0.2 takes precedence over earlier copies in the Illustrator installation folder; that older copy is left intact.

This is an unsigned local extension. The installer sets `HKCU\Software\Adobe\CSXS.12\PlayerDebugMode` to string `1`, as required to load an unsigned CEP 12 panel. It records the prior value in an installation receipt. No administrator access is normally needed. No certificate or signed ZXP is included.

## Use

Choose a preset, artboards and units. Margins can be linked or set separately. Columns and rows support counts, gutters and fixed sizes; leave fixed sizes blank for automatic division. The Preview checkbox shows temporary guides and updates when a setting is committed. Uncheck Preview to clear it. Create guides converts the current settings into final native guides on a separate layer.

Editable lines can use a custom HEX colour and appear in exports. Native guides use Illustrator's guide-colour preference. If hidden, choose View > Guides > Show Guides.

The panel follows Illustrator's background colour and updates when its theme event is received. All text is live HTML text with Adobe Clean / Segoe UI / Arial fallbacks. The panel supports narrow widths and vertical scrolling.

Switching documents clears the previous preview and turns Preview off when the panel detects the new document. A document identity check prevents a queued action from drawing in a different document. Click Refresh if the document label is stale.

Uncheck Preview before saving or closing a document. Panel hide/close requests cleanup, but an application crash or abrupt shutdown can interrupt that request. Reopening the panel cleans up tagged leftovers. Locked preview groups or groups with added artwork are protected; remove those manually if necessary. As with the script, preview changes can mark a document modified.

## If the menu item is missing

- Restart Illustrator after installation.
- Confirm the folder contains `CSXS/manifest.xml` directly inside `com.ashad.guidelayout`, without an extra nested copy of the folder.
- Use Illustrator 2026. This manifest targets host versions 30.0–30.9 and CEP 12.
- Check the installer completed successfully and the unsigned-extension setting was accepted.

## Uninstall

Save your work and close Illustrator. Run **Uninstall-Windows.cmd**. It removes only this extension after checking its receipt and destination. Keep the developer-mode setting if another unsigned panel needs it; the uninstaller offers optional restoration of the recorded prior value.

See TEST-REPORT.md for completed checks and limitations.

