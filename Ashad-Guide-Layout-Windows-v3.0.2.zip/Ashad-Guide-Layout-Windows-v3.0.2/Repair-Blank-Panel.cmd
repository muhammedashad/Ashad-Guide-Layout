@echo off
setlocal
title Ashad Guide Layout - Repair blank panel
if not exist "%~dp0Repair-Blank-Panel.ps1" (
  echo Extract the complete ZIP first, then run this file again.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Repair-Blank-Panel.ps1"
if errorlevel 1 (
  echo.
  echo REPAIR FAILED. Keep the error above for troubleshooting.
  pause
  exit /b 1
)
echo.
pause
exit /b 0
