/* Copyright (c) 2026 Ashad. All rights reserved. */
var AshadGuideCore = (function () {
    var factors = {px:1, pt:1, mm:72/25.4, cm:72/2.54, 'in':72};
    function defaults() { return {units:'px', target:'Active artboard', range:'1', margins:true, top:75, left:75, bottom:75, right:75, columns:true, cols:2, colWidth:'', colGap:0, rows:true, rowCount:2, rowHeight:'', rowGap:0, centerCols:false, centerRows:false, replace:false, mode:'Guides', color:'#00B8D9'}; }
    function number(v, label, max, integer) {
        var s=String(v).replace(/^\s+|\s+$/g,'');
        if(!/^\d+(\.\d+)?$/.test(s) || !isFinite(Number(s))) throw Error(label+': enter a positive number or zero.');
        var n=Number(s); if(n>max || (integer && (n<1 || Math.floor(n)!==n))) throw Error(label+': use '+(integer?'a whole number from 1 to ':'a value no greater than ')+max+'.');
        return n;
    }
    function indices(o,total,active) {
        if(o.target==='Active artboard')return [active];
        var out=[], seen={},i,j,parts,m;
        if(o.target==='All artboards'){for(i=0;i<total;i++)out.push(i);return out;}
        if(o.target!=='Artboard range')throw Error('Choose an artboard target.');
        parts=String(o.range).split(',');
        for(i=0;i<parts.length;i++){
            m=/^\s*(\d+)\s*(?:-\s*(\d+)\s*)?$/.exec(parts[i]);
            if(!m)throw Error('Artboard range: use 1, 3-5.');
            var a=Number(m[1]),b=m[2]?Number(m[2]):a;
            if(a<1 || b<a || b>total)throw Error('Artboard range must be between 1 and '+total+'.');
            for(j=a-1;j<b;j++)if(!seen[j]){out.push(j);seen[j]=true;}
        }
        return out;
    }
    function plan(o,rects,active) {
        var f=factors[o.units]; if(!f)throw Error('Choose valid units.');
        if(o.mode!=='Guides' && o.mode!=='Editable lines')throw Error('Choose an output type.');
        if(o.mode==='Editable lines'&&!/^#[0-9a-f]{6}$/i.test(o.color))throw Error('Line colour: use a six-digit HEX value, such as #00B8D9.');
        if(!o.margins&&!o.columns&&!o.rows)throw Error('Enable margins, columns, or rows.');
        var ids=indices(o,rects.length,active), result=[],count=0,margin={},k;
        for(k in {top:1,left:1,bottom:1,right:1})margin[k]=o.margins?number(o[k],k+' margin',100000,false)*f:0;
        function axis(start,end,n,gap,size,center,label) {
            n=number(n,label+' count',100,true);gap=number(gap,label+' gutter',100000,false)*f;
            var span=end-start, fixed=String(size).replace(/^\s+|\s+$/g,'')!=='';
            size=fixed?number(size,label+' size',100000,false)*f:(span-(n-1)*gap)/n;
            var used=n*size+(n-1)*gap;
            if(size<=0 || used>span+0.001)throw Error(label+' and gutters do not fit inside the margins.');
            var offset=center?(span-used)/2:0,lines=[];
            for(var q=0;q<n;q++){lines.push(start+offset+q*(size+gap));lines.push(start+offset+q*(size+gap)+size);}
            return lines;
        }
        for(var t=0;t<ids.length;t++){
            var id=ids[t],r=rects[id],L=r[0]+margin.left,R=r[2]-margin.right,T=r[1]-margin.top,B=r[3]+margin.bottom;
            if(R-L<=0.001 || T-B<=0.001)throw Error('Artboard '+(id+1)+': margins leave no usable area.');
            var xs=[],ys=[],paths=[],keys={};
            if(o.margins){xs.push(L,R);ys.push(T,B);}
            if(o.columns)xs=xs.concat(axis(L,R,o.cols,o.colGap,o.colWidth,o.centerCols,'Columns'));
            if(o.rows){var y=axis(-T,-B,o.rowCount,o.rowGap,o.rowHeight,o.centerRows,'Rows');for(var z=0;z<y.length;z++)ys.push(-y[z]);}
            function add(a,b,vertical){var key=(vertical?'x':'y')+Math.round((vertical?a[0]:a[1])*10000);if(!keys[key]){keys[key]=true;paths.push([a,b]);}}
            for(k=0;k<xs.length;k++)add([xs[k],r[1]],[xs[k],r[3]],true);
            for(k=0;k<ys.length;k++)add([r[0],ys[k]],[r[2],ys[k]],false);
            count+=paths.length;if(count>2000)throw Error('Layout exceeds 2,000 guides. Reduce the grid or artboard count.');
            result.push({index:id,rect:r,tag:'AshadGuideLayout:v1|'+r.join(','),paths:paths});
        }
        return {boards:result,count:count,mode:o.mode,color:o.mode==='Guides'?'#00B8D9':o.color,replace:!!o.replace};
    }
    function preset(n) {
        var o=defaults();
        if(n===1){o.columns=false;o.rows=false;}
        if(n===2){o.units='mm';o.top=o.left=o.bottom=o.right=15;o.cols=3;o.colGap=5;o.rows=false;}
        if(n===3){o.top=o.left=o.bottom=o.right=64;o.cols=12;o.colGap=24;o.rows=false;}
        if(n===4){o.top=o.left=o.bottom=o.right=60;o.cols=3;o.rowCount=3;o.colGap=o.rowGap=20;}
        if(n===5){o.margins=false;o.cols=o.rowCount=3;}
        return o;
    }
    return {defaults:defaults,plan:plan,preset:preset,indices:indices,factors:factors};
}());
