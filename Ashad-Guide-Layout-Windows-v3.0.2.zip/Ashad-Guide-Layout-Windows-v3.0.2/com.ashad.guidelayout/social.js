/* Copyright (c) 2026 Ashad. All rights reserved. */
(function () {
 'use strict';
 var buttons = document.querySelectorAll('[data-social-url]');
 var status = document.getElementById('socialStatus');
 for (var i = 0; i < buttons.length; i++) {
  buttons[i].addEventListener('click', function () {
   var url = this.getAttribute('data-social-url');
   try {
    if (!/^(https:\/\/|mailto:)/.test(url)) throw new Error('Unsupported link.');
    if (!window.cep || !window.cep.util || !window.cep.util.openURLInDefaultBrowser) {
     throw new Error('Open this extension in Illustrator to use these links.');
    }
    var result = window.cep.util.openURLInDefaultBrowser(url);
    var error = typeof result === 'number' ? result : result && result.err;
    if (error) throw new Error('Could not open the link. Check your default browser or email app.');
    status.textContent = url.indexOf('mailto:') === 0 ? 'Email app requested.' : 'Link opened in your default browser.';
   } catch (e) { status.textContent = e.message + ' ' + url; }
  });
 }
}());
