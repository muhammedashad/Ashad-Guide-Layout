/* Copyright (c) 2026 Ashad. All rights reserved. */
var AshadGuideWire=(function(){
 var defaults=AshadGuideCore.defaults(),keys=[],k;for(k in defaults)keys.push(k);
 function encode(o){var a=[];for(var i=0;i<keys.length;i++){var k=keys[i];a.push(encodeURIComponent(typeof defaults[k]==='boolean'?(o[k]?'1':'0'):String(o[k])));}return a.join('|');}
 function decode(s){var a=String(s).split('|'),o={};if(a.length!==keys.length)throw Error('Invalid settings. Reopen the panel.');for(var i=0;i<keys.length;i++){var k=keys[i],v=decodeURIComponent(a[i]);if(typeof defaults[k]==='boolean'){if(v!=='0'&&v!=='1')throw Error('Invalid checkbox value.');o[k]=v==='1';}else o[k]=v;}return o;}
 return {keys:keys,encode:encode,decode:decode};
}());
