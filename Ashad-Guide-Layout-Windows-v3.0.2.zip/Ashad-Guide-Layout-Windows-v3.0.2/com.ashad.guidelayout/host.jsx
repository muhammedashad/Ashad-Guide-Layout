/* Copyright (c) 2026 Ashad. All rights reserved. */
var AshadGuideCore = (function () {
    var factors = {px:1, pt:1, mm:72/25.4, cm:72/2.54, 'in':72};
    function defaults() { return {units:'px', target:'Active artboard', range:'1', margins:true, top:75, left:75, bottom:75, right:75, columns:true, cols:2, colWidth:'', colGap:0, rows:true, rowCount:2, rowHeight:'', rowGap:0, centerCols:false, centerRows:false, replace:false, mode:'Guides', color:'#00B8D9'}; }
    function number(v, label, max, integer) {
        var s=String(v).replace(/^\s+|\s+$/g,'');
        if(!/^\d+(\.\d+)?$/.test(s) || !isFinite(Number(s))) throw Error(label+': enter a positive number or zero.');
        var n=Number(s); if(n>max || (integer && (n<1 || Math.floor(n)!==n))) throw Error(label+': use '+(integer?'a whole number from 1 to ':'a value no greater than ')+max+'.');
        return n;
    }
    function indices(o,total,active) {
        if(o.target==='Active artboard')return [active];
        var out=[], seen={},i,j,parts,m;
        if(o.target==='All artboards'){for(i=0;i<total;i++)out.push(i);return out;}
        if(o.target!=='Artboard range')throw Error('Choose an artboard target.');
        parts=String(o.range).split(',');
        for(i=0;i<parts.length;i++){
            m=/^\s*(\d+)\s*(?:-\s*(\d+)\s*)?$/.exec(parts[i]);
            if(!m)throw Error('Artboard range: use 1, 3-5.');
            var a=Number(m[1]),b=m[2]?Number(m[2]):a;
            if(a<1 || b<a || b>total)throw Error('Artboard range must be between 1 and '+total+'.');
            for(j=a-1;j<b;j++)if(!seen[j]){out.push(j);seen[j]=true;}
        }
        return out;
    }
    function plan(o,rects,active) {
        var f=factors[o.units]; if(!f)throw Error('Choose valid units.');
        if(o.mode!=='Guides' && o.mode!=='Editable lines')throw Error('Choose an output type.');
        if(o.mode==='Editable lines'&&!/^#[0-9a-f]{6}$/i.test(o.color))throw Error('Line colour: use a six-digit HEX value, such as #00B8D9.');
        if(!o.margins&&!o.columns&&!o.rows)throw Error('Enable margins, columns, or rows.');
        var ids=indices(o,rects.length,active), result=[],count=0,margin={},k;
        for(k in {top:1,left:1,bottom:1,right:1})margin[k]=o.margins?number(o[k],k+' margin',100000,false)*f:0;
        function axis(start,end,n,gap,size,center,label) {
            n=number(n,label+' count',100,true);gap=number(gap,label+' gutter',100000,false)*f;
            var span=end-start, fixed=String(size).replace(/^\s+|\s+$/g,'')!=='';
            size=fixed?number(size,label+' size',100000,false)*f:(span-(n-1)*gap)/n;
            var used=n*size+(n-1)*gap;
            if(size<=0 || used>span+0.001)throw Error(label+' and gutters do not fit inside the margins.');
            var offset=center?(span-used)/2:0,lines=[];
            for(var q=0;q<n;q++){lines.push(start+offset+q*(size+gap));lines.push(start+offset+q*(size+gap)+size);}
            return lines;
        }
        for(var t=0;t<ids.length;t++){
            var id=ids[t],r=rects[id],L=r[0]+margin.left,R=r[2]-margin.right,T=r[1]-margin.top,B=r[3]+margin.bottom;
            if(R-L<=0.001 || T-B<=0.001)throw Error('Artboard '+(id+1)+': margins leave no usable area.');
            var xs=[],ys=[],paths=[],keys={};
            if(o.margins){xs.push(L,R);ys.push(T,B);}
            if(o.columns)xs=xs.concat(axis(L,R,o.cols,o.colGap,o.colWidth,o.centerCols,'Columns'));
            if(o.rows){var y=axis(-T,-B,o.rowCount,o.rowGap,o.rowHeight,o.centerRows,'Rows');for(var z=0;z<y.length;z++)ys.push(-y[z]);}
            function add(a,b,vertical){var key=(vertical?'x':'y')+Math.round((vertical?a[0]:a[1])*10000);if(!keys[key]){keys[key]=true;paths.push([a,b]);}}
            for(k=0;k<xs.length;k++)add([xs[k],r[1]],[xs[k],r[3]],true);
            for(k=0;k<ys.length;k++)add([r[0],ys[k]],[r[2],ys[k]],false);
            count+=paths.length;if(count>2000)throw Error('Layout exceeds 2,000 guides. Reduce the grid or artboard count.');
            result.push({index:id,rect:r,tag:'AshadGuideLayout:v1|'+r.join(','),paths:paths});
        }
        return {boards:result,count:count,mode:o.mode,color:o.mode==='Guides'?'#00B8D9':o.color,replace:!!o.replace};
    }
    function preset(n) {
        var o=defaults();
        if(n===1){o.columns=false;o.rows=false;}
        if(n===2){o.units='mm';o.top=o.left=o.bottom=o.right=15;o.cols=3;o.colGap=5;o.rows=false;}
        if(n===3){o.top=o.left=o.bottom=o.right=64;o.cols=12;o.colGap=24;o.rows=false;}
        if(n===4){o.top=o.left=o.bottom=o.right=60;o.cols=3;o.rowCount=3;o.colGap=o.rowGap=20;}
        if(n===5){o.margins=false;o.cols=o.rowCount=3;}
        return o;
    }
    return {defaults:defaults,plan:plan,preset:preset,indices:indices,factors:factors};
}());

/* Copyright (c) 2026 Ashad. All rights reserved. */
var AshadGuideHost = (function(){
    function rects(doc){var r=[];for(var i=0;i<doc.artboards.length;i++)r.push(doc.artboards[i].artboardRect);return r;}
    function discard(layer){if(layer){layer.locked=false;layer.remove();}}
    function draw(doc,plan,preview){
        var original=doc.activeLayer,layer=null,selection=doc.selection;
        try{
            layer=doc.layers.add();layer.name=preview?'Ashad Guide Layout - PREVIEW':'Ashad Guide Layout';
            var color=new RGBColor();color.red=parseInt(plan.color.substr(1,2),16);color.green=parseInt(plan.color.substr(3,2),16);color.blue=parseInt(plan.color.substr(5,2),16);layer.color=color;
            for(var b=0;b<plan.boards.length;b++){
                var board=plan.boards[b],group=layer.groupItems.add();group.name='Artboard '+(board.index+1)+' / Ashad';group.note=preview?'AshadGuidePreview':board.tag;
                for(var i=0;i<board.paths.length;i++){
                    var p=group.pathItems.add();p.setEntirePath(board.paths[i]);p.filled=false;p.stroked=true;p.strokeWidth=0.5;p.strokeColor=color;
                    p.note='AshadGuidePath:v1';p.guides=plan.mode==='Guides';p.selected=false;
                }
            }
            return layer;
        }catch(e){if(layer)discard(layer);throw e;}
        finally{try{doc.activeLayer=original;doc.selection=selection;}catch(ignore){}}
    }
    function replace(doc,plan,newLayer){
        var tags={},old=[],i,j,skipped=0;
        for(i=0;i<plan.boards.length;i++)tags[plan.boards[i].tag]=true;
        for(i=0;i<doc.groupItems.length;i++){var g=doc.groupItems[i];if(g.layer!==newLayer && tags[g.note])old.push(g);}
        for(i=old.length-1;i>=0;i--){
            var item=old[i],layer=item.layer;
            // Never remove a group containing user-added artwork or nested groups.
            var safe=item.groupItems.length===0 && item.pageItems.length===item.pathItems.length;
            for(j=0;j<item.pathItems.length && safe;j++)if(item.pathItems[j].note!=='AshadGuidePath:v1')safe=false;
            if(!safe || layer.locked || item.locked || layer.visible===false){skipped++;continue;}
            try{item.remove();if(layer.pageItems.length===0 && layer.name==='Ashad Guide Layout')layer.remove();}catch(e){skipped++;}
        }
        return skipped;
    }
    function create(doc,plan,preview){
        return draw(doc,plan,preview);
    }
    return {rects:rects,create:create,discard:discard,replace:replace};
}());

/* Copyright (c) 2026 Ashad. All rights reserved. */
var AshadGuideWire=(function(){
 var defaults=AshadGuideCore.defaults(),keys=[],k;for(k in defaults)keys.push(k);
 function encode(o){var a=[];for(var i=0;i<keys.length;i++){var k=keys[i];a.push(encodeURIComponent(typeof defaults[k]==='boolean'?(o[k]?'1':'0'):String(o[k])));}return a.join('|');}
 function decode(s){var a=String(s).split('|'),o={};if(a.length!==keys.length)throw Error('Invalid settings. Reopen the panel.');for(var i=0;i<keys.length;i++){var k=keys[i],v=decodeURIComponent(a[i]);if(typeof defaults[k]==='boolean'){if(v!=='0'&&v!=='1')throw Error('Invalid checkbox value.');o[k]=v==='1';}else o[k]=v;}return o;}
 return {keys:keys,encode:encode,decode:decode};
}());

/* Copyright (c) 2026 Ashad. All rights reserved. */
var AshadGuideCEP=(function(){
 var docs=[],serial=0,previewDoc=null;
 function token(doc){for(var i=0;i<docs.length;i++)try{if(docs[i].doc===doc)return docs[i].id;}catch(ignore){}var id='d'+(++serial);docs.push({doc:doc,id:id});return id;}
 function clear(){
  // Durable ownership tags also recover a preview after a panel reload.
  var skipped=0;
  for(var n=0;n<app.documents.length;n++){
   var d=app.documents[n],groups=[];
   for(var j=0;j<d.groupItems.length;j++)if(d.groupItems[j].note==='AshadGuideCEPPreview:v1')groups.push(d.groupItems[j]);
   for(var k=groups.length-1;k>=0;k--){var g=groups[k],l=g.layer,safe=g.pageItems.length===g.pathItems.length&&g.groupItems.length===0;
    for(j=0;j<g.pathItems.length&&safe;j++)if(g.pathItems[j].note!=='AshadGuidePath:v1')safe=false;
    if(!safe||l.locked||g.locked){skipped++;continue;}
    g.remove();if(l.pageItems.length===0&&l.name==='Ashad Guide Layout - PREVIEW')l.remove();
   }
  }
  previewDoc=null;app.redraw();return skipped;
 }
 function reply(ok,msg,id){return (ok?'OK':'ERR')+'|'+encodeURIComponent(msg)+'|'+encodeURIComponent(id||'');}
 function run(action,wire,expected){
  try{
   if(action==='clear'||action==='init'){var kept=clear();return reply(true,kept?'Some previews were kept because they are locked or contain added artwork.':'Preview cleared.');}
   if(!app.documents.length){clear();return reply(false,'Open an Illustrator document first.');}
   var d=app.activeDocument,id=token(d);
   if(previewDoc&&previewDoc!==d)clear();
   if(action==='info')return reply(true,d.name+' | '+d.artboards.length+' artboard(s) | Active: '+(d.artboards.getActiveArtboardIndex()+1),id);
   if(action!=='preview'&&action!=='create')throw Error('Unknown command.');
   if(!expected||expected!==id){clear();throw Error('The active document changed. Refresh, then try again.');}
   clear();var o=AshadGuideWire.decode(wire),p=AshadGuideCore.plan(o,AshadGuideHost.rects(d),d.artboards.getActiveArtboardIndex()),l=AshadGuideHost.create(d,p,action==='preview'),skipped=0;
   if(action==='preview'){for(var b=0;b<l.groupItems.length;b++)l.groupItems[b].note='AshadGuideCEPPreview:v1';previewDoc=d;}
   else if(p.replace)skipped=AshadGuideHost.replace(d,p,l);
   app.redraw();return reply(true,(action==='preview'?'Preview: ':'Created ')+p.count+' '+(p.mode==='Guides'?'guides':'lines')+' on '+p.boards.length+' artboard(s).'+(skipped?' Some older groups were protected.':''),id);
  }catch(e){return reply(false,e.message);}
 }
 return {run:run};
}());
