/* Copyright (c) 2026 Ashad. All rights reserved. */
(function(){'use strict';
 var core=AshadGuideCore,wire=AshadGuideWire,bridge=window.__adobe_cep__,busy=false,pending=null,docToken='',previousUnit='px',timer=null,infoTimer=null;
 function el(id){return document.getElementById(id);}function message(text,error){el('status').textContent=text;el('status').className=error?'error':'';}
 function theme(){try{var h=JSON.parse(bridge.getHostEnvironment()),c=h.appSkinInfo.panelBackgroundColor.color;var light=(c.red+c.green+c.blue)>420;document.documentElement.style.setProperty('--bg','rgb('+c.red+','+c.green+','+c.blue+')');document.documentElement.classList.toggle('light',light);}catch(ignore){}}
 function read(){var o={};wire.keys.forEach(function(k){o[k]=el(k).type==='checkbox'?el(k).checked:el(k).value;});if(el('link').checked)o.left=o.bottom=o.right=o.top;return o;}
 function put(o){wire.keys.forEach(function(k){if(el(k).type==='checkbox')el(k).checked=o[k];else el(k).value=o[k];});previousUnit=o.units;sync();}
 function sync(){var linked=el('link').checked;['top','left','bottom','right'].forEach(function(k){if(linked&&k!=='top')el(k).value=el('top').value;el(k).disabled=!el('margins').checked||(linked&&k!=='top');});el('link').disabled=!el('margins').checked;el('range').disabled=el('target').value!=='Artboard range';el('color').disabled=el('mode').value==='Guides';['cols','colWidth','colGap'].forEach(function(k){el(k).disabled=!el('columns').checked;});['rowCount','rowHeight','rowGap'].forEach(function(k){el(k).disabled=!el('rows').checked;});el('centerCols').disabled=!el('columns').checked||el('colWidth').value==='';el('centerRows').disabled=!el('rows').checked||el('rowHeight').value==='';el('create').textContent=el('mode').value==='Guides'?'Create guides':'Create lines';el('colourHelp').textContent=el('mode').value==='Guides'?'Guide colour follows Illustrator Preferences.':'Editable lines appear in print and exports.';}
 function locked(on){busy=on;el('create').disabled=on||!bridge;el('reset').disabled=on;el('preset').disabled=on;}
 function invoke(action){
  if(!bridge){message('Open this panel from Illustrator > Window > Extensions.',true);return;}
  if(busy){if(action!=='info'&&pending!=='create')pending=action;return;}
  var settings=wire.encode(read()),expected=docToken;locked(true);
  try{bridge.evalScript('AshadGuideCEP.run('+JSON.stringify(action)+','+JSON.stringify(settings)+','+JSON.stringify(expected)+')',function(raw){
   locked(false);try{var parts=String(raw).split('|');if(parts.length!==3||!/^(OK|ERR)$/.test(parts[0]))throw Error('Illustrator could not load the panel engine. Close and reopen this panel.');var ok=parts[0]==='OK',msg=decodeURIComponent(parts[1]),id=decodeURIComponent(parts[2]);
    if(action==='info'){el('documentInfo').textContent=msg;if(docToken&&id!==docToken){el('preview').checked=false;message('Document changed. Preview is off.');}docToken=id;if(!ok)message(msg,true);}
    else if(action==='init'){invoke('info');return;}
    else{message(msg,!ok);if(action==='create'&&ok)el('preview').checked=false;}
   }catch(e){message(e.message,true);el('preview').checked=false;}
   if(pending){var next=pending;pending=null;if(next==='preview'&&!el('preview').checked)next='clear';invoke(next);}
  });}catch(e){locked(false);message(e.message,true);pending=null;}
 }
 function changed(){sync();clearTimeout(timer);timer=setTimeout(function(){invoke(el('preview').checked?'preview':'clear');},180);}
 wire.keys.concat(['link']).forEach(function(k){el(k).addEventListener('change',function(){if(k==='units'){var next=el('units').value;['top','left','bottom','right','colWidth','colGap','rowHeight','rowGap'].forEach(function(name){var v=el(name).value;if(/^\s*\d+(\.\d+)?\s*$/.test(v))el(name).value=String(Math.round(Number(v)*core.factors[previousUnit]/core.factors[next]*1000000)/1000000);});previousUnit=next;}changed();});});
 el('preview').addEventListener('change',function(){clearTimeout(timer);invoke(el('preview').checked?'preview':'clear');});
 el('create').addEventListener('click',function(){clearTimeout(timer);invoke('create');});
 el('refresh').addEventListener('click',function(){invoke('info');});
 el('reset').addEventListener('click',function(){el('link').checked=true;el('preset').value='0';put(core.defaults());changed();});
 el('preset').addEventListener('change',function(){var old=read(),o=core.preset(Number(el('preset').value));o.target=old.target;o.range=old.range;o.mode=old.mode;o.color=old.color;o.replace=old.replace;put(o);changed();});
 function stopPreview(){clearTimeout(timer);el('preview').checked=false;invoke('clear');}
 document.addEventListener('visibilitychange',function(){if(document.hidden)stopPreview();else invoke('info');});window.addEventListener('beforeunload',stopPreview);
 put(core.defaults());if(bridge){theme();try{bridge.addEventListener('com.adobe.csxs.events.ThemeColorChanged',theme);}catch(ignore){}invoke('init');infoTimer=setInterval(function(){if(!document.hidden&&!busy)invoke('info');},1800);}else{locked(false);message('Install this panel, then open Window > Extensions > Ashad Guide Layout.',true);}
}());
