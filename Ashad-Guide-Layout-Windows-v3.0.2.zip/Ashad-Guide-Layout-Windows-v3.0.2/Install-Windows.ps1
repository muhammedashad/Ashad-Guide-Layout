param([switch]$Approved)
$ErrorActionPreference = 'Stop'
$extensionId = 'com.ashad.guidelayout'
$sourcePath = Join-Path $PSScriptRoot $extensionId
$extensionRoot = [IO.Path]::GetFullPath((Join-Path $env:APPDATA 'Adobe\CEP\extensions'))
$targetPath = [IO.Path]::GetFullPath((Join-Path $extensionRoot $extensionId))
$registryPath = 'HKCU:\Software\Adobe\CSXS.12'
if ([IO.Path]::GetDirectoryName($targetPath) -ne $extensionRoot -or [IO.Path]::GetFileName($targetPath) -ne $extensionId) { throw 'Unexpected installation path.' }
Write-Host 'Ashad Guide Layout - dockable Illustrator extension' -ForegroundColor Green
Write-Host 'Installs for this Windows user. Existing extensions are kept.'
Write-Host 'This unsigned panel needs CEP 12 developer mode, which allows unsigned CEP 12 extensions.'
if (!$Approved -and (Read-Host 'Install and enable this setting? Type YES') -cne 'YES') { exit 0 }
if (Get-Process -Name Illustrator -ErrorAction SilentlyContinue) { throw 'Save your work and close Illustrator normally, then run this installer again.' }
foreach ($file in @('CSXS\manifest.xml','index.html','style.css','panel.js','host.jsx','core.js','wire.js','social.js')) {
 if (!(Test-Path -LiteralPath (Join-Path $sourcePath $file))) { throw 'Extract the complete ZIP before installing.' }
}
if (Test-Path -LiteralPath $targetPath) {
 [xml]$existingManifest = Get-Content -LiteralPath (Join-Path $targetPath 'CSXS\manifest.xml') -Raw
 if ($existingManifest.ExtensionManifest.ExtensionBundleId -ne $extensionId) { throw 'The existing folder has an unexpected extension ID.' }
 $backupRoot = Join-Path $env:LOCALAPPDATA 'Ashad\Guide Layout\Extension backups'
 New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
 $backupPath = Join-Path $backupRoot ([guid]::NewGuid().ToString('N'))
 Copy-Item -LiteralPath $targetPath -Destination $backupPath -Recurse
 Write-Host "Previous panel backed up: $backupPath"
}
$oldValue = Get-ItemPropertyValue -LiteralPath $registryPath -Name PlayerDebugMode -ErrorAction SilentlyContinue
$hadValue = $null -ne $oldValue
$oldKind = if ($hadValue) { (Get-Item -LiteralPath $registryPath).GetValueKind('PlayerDebugMode').ToString() } else { 'String' }
New-Item -ItemType Directory -Path $extensionRoot -Force | Out-Null
New-Item -ItemType Directory -Path $targetPath -Force | Out-Null
foreach ($sourceItem in Get-ChildItem -LiteralPath $sourcePath) {
 Copy-Item -LiteralPath $sourceItem.FullName -Destination $targetPath -Recurse -Force
}
$receiptPath = Join-Path $targetPath 'install-receipt.json'
if (!(Test-Path -LiteralPath $receiptPath)) {
 @{ExtensionId=$extensionId;HadValue=$hadValue;OldValue=$oldValue;OldKind=$oldKind} | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding UTF8
}
New-Item -Path $registryPath -Force | Out-Null
New-ItemProperty -LiteralPath $registryPath -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
Write-Host 'Installed. Save your work and restart Illustrator.' -ForegroundColor Green
Write-Host 'Then open Window > Extensions > Ashad Guide Layout.'
